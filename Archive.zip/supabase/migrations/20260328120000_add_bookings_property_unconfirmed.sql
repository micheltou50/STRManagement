-- Email import: flag rows where AI could not match listing to a property (multi-property hosts).
ALTER TABLE bookings
  ADD COLUMN IF NOT EXISTS property_unconfirmed boolean DEFAULT false;
